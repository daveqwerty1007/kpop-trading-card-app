import pandas as pd
from sqlalchemy import create_engine, Table, Column, Integer, String, Float, MetaData

DB_CONFIG = {
    'host': 'database-1.cbko6om64nur.us-east-1.rds.amazonaws.com',
    'user': 'admin',
    'password': 'nCbx9SyJPoUXXT8zcw4d',
    'database': 'kpop_trading'
}

DATABASE_URI = f"mysql+mysqlconnector://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}/{DB_CONFIG['database']}"
engine = create_engine(DATABASE_URI)

cards_csv_path = '/path/to/your/ProductionData/Cards.csv'
cards_data = pd.read_csv(cards_csv_path)

metadata = MetaData()

cards_table = Table(
    'cards', metadata,
    Column('id', Integer, primary_key=True),
    Column('card_name', String),
    Column('artist', String),
    Column('group', String),
    Column('album', String),
    Column('price', Float),
    Column('description', String),
    Column('image_url', String)
)